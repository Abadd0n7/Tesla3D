﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using TMPro;
using System;
using System.Net;
using System.IO;
using Newtonsoft.Json;

public class LaunchText : MonoBehaviour
{
    public TextMeshProUGUI Text;
    ///private string API = "https://api.spacexdata.com/v3/";
    private string launches = "https://api.spacexdata.com/v3/launches";
    
    void Start()
    {
        StartCoroutine(GetText());
    }

    IEnumerator GetText()
    {
        UnityWebRequest request = UnityWebRequest.Get(launches);
        yield return request.SendWebRequest();

        if (request.isNetworkError || request.isHttpError)
        {
            Debug.Log(request.error);
        }
        else
        {
            string _text;

            _text = request.downloadHandler.text;

            var myJson = JsonConvert.DeserializeObject<List<Launch>>(_text);

            //var x = myJson[15];
            //Text.text = x.flight_number.ToString();
            Text.text = "";
            foreach (var x in myJson)
            {
                Text.text += x.flight_number +"\n";
                //Debug.Log(x.flight_number);
            }
            //DARIUSZ! TU SIĘ PATRZ :D
            //Potrzebuję coś takiego:
            //Each interactable element in the list should represent one SpaceX launch and provide text with name 
            //of the mission and number of payloads that were involved in the mission, as well as the name 
            //of the rocket used in the launch and it's country of origin.
            //Do tego muszę wstawić obrazek czy misja już się odbyła czy jeszcze nie.
        }
    }
}


public class Launch 
{
    public int flight_number { get; set; }
    public string mission_name { get; set; }
    //public IList<object> mission_id { get; set; }
    public bool upcoming { get; set; }
    public string launch_year { get; set; }
    public int launch_date_unix { get; set; }
    public DateTime launch_date_utc { get; set; }
    public DateTime launch_date_local { get; set; }
    public bool is_tentative { get; set; }
    public string tentative_max_precision { get; set; }
    public bool tbd { get; set; }
    public int launch_window { get; set; }
    public Rocket rocket { get; set; }
    //public IList<object> ships { get; set; }
    //public Telemetry telemetry { get; set; }
    //public LaunchSite launch_site { get; set; }
    //public bool launch_success { get; set; }
    //public LaunchFailureDetails launch_failure_details { get; set; }
    //public Links links { get; set; }
    //public string details { get; set; }
    //public DateTime static_fire_date_utc { get; set; }
    //public int static_fire_date_unix { get; set; }
    //public Timeline timeline { get; set; }
}
public class Core
{
    public string core_serial { get; set; }
    public int flight { get; set; }
    public object block { get; set; }
    public bool gridfins { get; set; }
    public bool legs { get; set; }
    public bool reused { get; set; }
    public object land_success { get; set; }
    public bool landing_intent { get; set; }
    public object landing_type { get; set; }
    public object landing_vehicle { get; set; }
}

public class FirstStage
{
    //public IList<Core> cores { get; set; }
}

public class OrbitParams
{
    public string reference_system { get; set; }
    public string regime { get; set; }
    public object longitude { get; set; }
    public object semi_major_axis_km { get; set; }
    public object eccentricity { get; set; }
    public int periapsis_km { get; set; }
    public int apoapsis_km { get; set; }
    public int inclination_deg { get; set; }
    public object period_min { get; set; }
    public object lifespan_years { get; set; }
    public object epoch { get; set; }
    public object mean_motion { get; set; }
    public object raan { get; set; }
    public object arg_of_pericenter { get; set; }
    public object mean_anomaly { get; set; }
}

public class Payload
{
    public string payload_id { get; set; }
    //public IList<object> norad_id { get; set; }
    public bool reused { get; set; }
    //public IList<string> customers { get; set; }
    public string nationality { get; set; }
    public string manufacturer { get; set; }
    public string payload_type { get; set; }
    public int payload_mass_kg { get; set; }
    public int payload_mass_lbs { get; set; }
    public string orbit { get; set; }
    public OrbitParams orbit_params { get; set; }
}

public class SecondStage
{
    public int block { get; set; }
    //public IList<Payload> payloads { get; set; }
}

public class Fairings
{
    public bool reused { get; set; }
    public bool recovery_attempt { get; set; }
    public bool recovered { get; set; }
    public object ship { get; set; }
}

public class Rocket
{
    public string rocket_id { get; set; }
    public string rocket_name { get; set; }
    public string rocket_type { get; set; }
    public FirstStage first_stage { get; set; }
    public SecondStage second_stage { get; set; }
    public Fairings fairings { get; set; }
}

public class Telemetry
{
    public object flight_club { get; set; }
}

public class LaunchSite
{
    public string site_id { get; set; }
    public string site_name { get; set; }
    public string site_name_long { get; set; }
}

public class LaunchFailureDetails
{
    public int time { get; set; }
    public object altitude { get; set; }
    public string reason { get; set; }
}

public class Links
{
    public string mission_patch { get; set; }
    public string mission_patch_small { get; set; }
    public object reddit_campaign { get; set; }
    public object reddit_launch { get; set; }
    public object reddit_recovery { get; set; }
    public object reddit_media { get; set; }
    public object presskit { get; set; }
    public string article_link { get; set; }
    public string wikipedia { get; set; }
    public string video_link { get; set; }
    public string youtube_id { get; set; }
    //public IList<object> flickr_images { get; set; }
}

public class Timeline
{
    public int webcast_liftoff { get; set; }
}







