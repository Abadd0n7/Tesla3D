﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IsVisible : MonoBehaviour
{
    public GameObject go;
    void Start()
    {
        go.SetActive(false);
    }
    void OnTriggerEnter(Collider col)
    {
        go.SetActive(true);
        Debug.Log("!!!");
    }

    void Update()
    {

    }
}
