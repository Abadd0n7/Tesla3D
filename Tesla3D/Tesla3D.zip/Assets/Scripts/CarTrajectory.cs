﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarTrajectory : MonoBehaviour
{
    float timeCounter = 0;
    void Start()
    {
    
    }
    // Update is called once per frame
    void Update()
    {
        timeCounter += Time.deltaTime*0.3f;

        float x = Mathf.Sin(timeCounter) * 300;
        float y = Mathf.Cos(timeCounter) * 600;
        float z = (Mathf.Sin(timeCounter) + Mathf.Cos(timeCounter)) * 100;

        transform.position = new Vector3(x, y, z);
       
    }
}
